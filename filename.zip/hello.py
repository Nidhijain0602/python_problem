class hello:
    def fuc(self):
        print('hello')
a=hello()
a.fuc()

